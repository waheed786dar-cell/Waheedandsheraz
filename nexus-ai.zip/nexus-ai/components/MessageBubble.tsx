"use client";

import { useState, useCallback } from "react";
import { motion } from "framer-motion";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { oneDark, oneLight } from "react-syntax-highlighter/dist/esm/styles/prism";
import { Copy, Check, User, Sparkles, RefreshCw } from "lucide-react";
import type { Message } from "@/hooks/useChat";

interface MessageBubbleProps {
  message: Message;
  isStreaming?: boolean;
  theme: "dark" | "light";
  index: number;
}

function CodeBlock({ code, language, theme }: { code: string; language: string; theme: string }) {
  const [copied, setCopied] = useState(false);

  const copy = useCallback(async () => {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [code]);

  return (
    <div
      className="code-block rounded-xl overflow-hidden my-3 border"
      style={{ borderColor: "var(--border-subtle)" }}
    >
      <div
        className="flex items-center justify-between px-4 py-2"
        style={{ background: theme === "dark" ? "#1a1d2e" : "#f0f2f8" }}
      >
        <span className="text-xs font-mono font-medium" style={{ color: "var(--text-muted)" }}>
          {language || "code"}
        </span>
        <button
          onClick={copy}
          className="flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-lg transition-all duration-200 hover:scale-105 active:scale-95"
          style={{
            background: copied ? "rgba(34,197,94,0.15)" : "var(--border-subtle)",
            color: copied ? "#22c55e" : "var(--text-muted)",
          }}
        >
          {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
          {copied ? "Copied!" : "Copy"}
        </button>
      </div>
      <SyntaxHighlighter
        style={theme === "dark" ? oneDark : oneLight}
        language={language}
        PreTag="div"
        customStyle={{ margin: 0, borderRadius: 0, fontSize: "13px" }}
      >
        {code}
      </SyntaxHighlighter>
    </div>
  );
}

export default function MessageBubble({ message, isStreaming, theme, index }: MessageBubbleProps) {
  const isUser = message.role === "user";
  const isEmpty = !message.content && isStreaming && !isUser;

  return (
    <motion.div
      initial={{ opacity: 0, y: 16, scale: 0.97 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.35, ease: [0.34, 1.56, 0.64, 1], delay: index * 0.02 }}
      className={`flex gap-3 ${isUser ? "flex-row-reverse" : "flex-row"} group`}
    >
      {/* Avatar */}
      <div
        className="w-8 h-8 rounded-xl flex-shrink-0 flex items-center justify-center mt-0.5 relative overflow-hidden"
        style={{
          background: isUser
            ? "linear-gradient(135deg, #5a6ef8, #3d4eec)"
            : theme === "dark"
            ? "rgba(26,29,46,0.9)"
            : "rgba(240,242,248,0.9)",
          border: isUser ? "none" : "1px solid var(--border-medium)",
          boxShadow: isUser ? "0 4px 12px rgba(90,110,248,0.3)" : "var(--shadow-sm)",
        }}
      >
        {isUser ? (
          <User className="w-4 h-4 text-white" />
        ) : (
          <Sparkles className="w-4 h-4" style={{ color: "var(--accent)" }} />
        )}
      </div>

      {/* Bubble */}
      <div className={`flex-1 ${isUser ? "flex justify-end" : ""}`} style={{ maxWidth: "85%" }}>
        {message.imageUrl && (
          <div className="mb-2">
            <img
              src={message.imageUrl}
              alt="Uploaded"
              className="max-h-48 w-auto rounded-xl object-cover border"
              style={{ borderColor: "var(--border-medium)" }}
            />
          </div>
        )}

        <div
          className={`rounded-2xl px-4 py-3 relative ${isUser ? "rounded-tr-sm" : "rounded-tl-sm"}`}
          style={{
            background: isUser
              ? "linear-gradient(135deg, #5a6ef8 0%, #3d4eec 100%)"
              : "var(--ai-bubble)",
            backdropFilter: !isUser ? "blur(20px)" : "none",
            border: !isUser ? "1px solid var(--border-subtle)" : "none",
            boxShadow: isUser
              ? "0 4px 20px rgba(90,110,248,0.25), 0 2px 6px rgba(90,110,248,0.15)"
              : "var(--shadow-sm)",
            color: isUser ? "#fff" : "var(--text-primary)",
          }}
        >
          {isEmpty ? (
            <div className="flex items-center gap-1.5 h-5">
              {[0, 1, 2].map((i) => (
                <div key={i} className="typing-dot" style={{ animationDelay: `${i * 0.2}s` }} />
              ))}
            </div>
          ) : isUser ? (
            <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
          ) : (
            <div className="prose-custom text-sm">
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                components={{
                  code({ node, className, children, ...props }) {
                    const match = /language-(\w+)/.exec(className || "");
                    const isBlock = !!(node?.position && String(children).includes("\n"));
                    if (match || isBlock) {
                      return (
                        <CodeBlock
                          code={String(children).replace(/\n$/, "")}
                          language={match?.[1] || "text"}
                          theme={theme}
                        />
                      );
                    }
                    return (
                      <code className={className} {...props}>
                        {children}
                      </code>
                    );
                  },
                }}
              >
                {message.content}
              </ReactMarkdown>
              {isStreaming && (
                <motion.span
                  animate={{ opacity: [1, 0, 1] }}
                  transition={{ repeat: Infinity, duration: 0.8 }}
                  className="inline-block w-0.5 h-4 ml-0.5 rounded-full align-middle"
                  style={{ background: "var(--accent)" }}
                />
              )}
            </div>
          )}
        </div>

        {/* Timestamp */}
        <div
          className={`flex items-center gap-2 mt-1.5 opacity-0 group-hover:opacity-100 transition-opacity duration-200 ${isUser ? "justify-end" : "justify-start"}`}
        >
          <span className="text-xs" style={{ color: "var(--text-muted)" }}>
            {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </span>
        </div>
      </div>
    </motion.div>
  );
}
