"use client";

import { useState, useRef, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Send, Square, Mic, MicOff, Paperclip, X, ImageIcon, Sparkles,
} from "lucide-react";

interface ChatInputProps {
  onSend: (message: string, imageUrl?: string) => void;
  onStop: () => void;
  isStreaming: boolean;
  disabled?: boolean;
}

// Extend window for SpeechRecognition
declare global {
  interface Window {
    SpeechRecognition: typeof SpeechRecognition;
    webkitSpeechRecognition: typeof SpeechRecognition;
  }
}

const PLACEHOLDER_HINTS = [
  "Ask me anything…",
  "Explain quantum computing…",
  "Write me a Python script…",
  "Summarize this concept…",
  "Help me debug this code…",
  "Generate creative ideas…",
];

export default function ChatInput({ onSend, onStop, isStreaming, disabled }: ChatInputProps) {
  const [input, setInput] = useState("");
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const [placeholderIdx, setPlaceholderIdx] = useState(0);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  // Cycle placeholders
  useEffect(() => {
    const interval = setInterval(() => {
      setPlaceholderIdx((i) => (i + 1) % PLACEHOLDER_HINTS.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  // Auto resize textarea
  const autoResize = useCallback(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 200)}px`;
  }, []);

  useEffect(() => {
    autoResize();
  }, [input, autoResize]);

  const handleSend = useCallback(() => {
    if (isStreaming) { onStop(); return; }
    if (!input.trim() && !imageUrl) return;
    onSend(input.trim(), imageUrl ?? undefined);
    setInput("");
    setImageUrl(null);
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.focus();
    }
  }, [input, imageUrl, isStreaming, onSend, onStop]);

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        handleSend();
      }
    },
    [handleSend]
  );

  // Voice input
  const toggleVoice = useCallback(() => {
    const SpeechAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechAPI) { alert("Speech recognition not supported in this browser."); return; }

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    const recognition = new SpeechAPI();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = "en-US";

    recognition.onresult = (e) => {
      const transcript = Array.from(e.results)
        .map((r) => r[0].transcript)
        .join("");
      setInput(transcript);
    };

    recognition.onend = () => setIsListening(false);
    recognition.onerror = () => setIsListening(false);

    recognitionRef.current = recognition;
    recognition.start();
    setIsListening(true);
  }, [isListening]);

  // Image upload
  const handleImageUpload = useCallback((file: File) => {
    if (!file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = (e) => setImageUrl(e.target?.result as string);
    reader.readAsDataURL(file);
  }, []);

  const handleFileChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) handleImageUpload(file);
    },
    [handleImageUpload]
  );

  // Drag & drop
  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback(() => setIsDragging(false), []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      const file = e.dataTransfer.files?.[0];
      if (file) handleImageUpload(file);
    },
    [handleImageUpload]
  );

  const canSend = (input.trim().length > 0 || !!imageUrl) && !disabled;

  return (
    <div className="relative">
      {/* Drag overlay */}
      <AnimatePresence>
        {isDragging && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-20 rounded-2xl border-2 border-dashed flex items-center justify-center"
            style={{ borderColor: "var(--accent)", background: "var(--accent-glow)" }}
          >
            <div className="text-center">
              <ImageIcon className="w-8 h-8 mx-auto mb-2" style={{ color: "var(--accent)" }} />
              <p className="text-sm font-medium" style={{ color: "var(--accent)" }}>Drop image here</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        animate={{
          boxShadow: isFocused
            ? "0 0 0 2px var(--accent), 0 8px 32px rgba(90,110,248,0.15)"
            : "var(--shadow-md)",
        }}
        transition={{ duration: 0.2 }}
        className="glass-heavy rounded-2xl overflow-hidden"
        style={{ background: "var(--bg-card)" }}
      >
        {/* Image preview */}
        <AnimatePresence>
          {imageUrl && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="px-4 pt-3 pb-0"
            >
              <div className="relative inline-block">
                <img
                  src={imageUrl}
                  alt="Upload preview"
                  className="h-20 w-auto rounded-xl object-cover border"
                  style={{ borderColor: "var(--border-medium)" }}
                />
                <button
                  onClick={() => setImageUrl(null)}
                  className="absolute -top-2 -right-2 w-5 h-5 rounded-full flex items-center justify-center text-xs"
                  style={{ background: "var(--text-secondary)", color: "var(--bg-primary)" }}
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Input row */}
        <div className="flex items-end gap-2 p-3">
          {/* Left actions */}
          <div className="flex items-center gap-1 pb-1">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-8 h-8 rounded-xl flex items-center justify-center transition-all duration-200 hover:scale-110 active:scale-95"
              style={{ color: "var(--text-muted)" }}
              title="Attach image"
            >
              <Paperclip className="w-4 h-4" />
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileChange}
            />
          </div>

          {/* Textarea */}
          <div className="flex-1 relative">
            <AnimatePresence mode="wait">
              {!isFocused && !input && (
                <motion.span
                  key={placeholderIdx}
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -4 }}
                  transition={{ duration: 0.25 }}
                  className="absolute inset-0 flex items-center pointer-events-none text-sm"
                  style={{ color: "var(--text-muted)" }}
                >
                  {PLACEHOLDER_HINTS[placeholderIdx]}
                </motion.span>
              )}
            </AnimatePresence>
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              rows={1}
              disabled={disabled}
              className="w-full resize-none bg-transparent text-sm leading-relaxed focus:outline-none"
              style={{
                color: "var(--text-primary)",
                minHeight: "24px",
                maxHeight: "200px",
                fontFamily: "var(--font-geist)",
              }}
            />
          </div>

          {/* Right actions */}
          <div className="flex items-center gap-1 pb-1">
            {/* Voice */}
            <motion.button
              onClick={toggleVoice}
              whileTap={{ scale: 0.9 }}
              className="w-8 h-8 rounded-xl flex items-center justify-center transition-all duration-200"
              style={{
                color: isListening ? "#ef4444" : "var(--text-muted)",
                background: isListening ? "rgba(239,68,68,0.1)" : "transparent",
              }}
              title={isListening ? "Stop listening" : "Voice input"}
            >
              {isListening ? (
                <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ repeat: Infinity, duration: 0.8 }}>
                  <MicOff className="w-4 h-4" />
                </motion.div>
              ) : (
                <Mic className="w-4 h-4" />
              )}
            </motion.button>

            {/* Send / Stop */}
            <motion.button
              onClick={handleSend}
              whileTap={{ scale: 0.9 }}
              disabled={!canSend && !isStreaming}
              className="w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-200 relative overflow-hidden"
              style={{
                background: isStreaming
                  ? "linear-gradient(135deg, #ef4444, #dc2626)"
                  : canSend
                  ? "linear-gradient(135deg, #5a6ef8, #3d4eec)"
                  : "var(--border-subtle)",
                color: canSend || isStreaming ? "#fff" : "var(--text-muted)",
                boxShadow: isStreaming || canSend ? "0 4px 16px rgba(90,110,248,0.3)" : "none",
              }}
            >
              {isStreaming ? (
                <Square className="w-3.5 h-3.5 fill-current" />
              ) : (
                <Send className="w-3.5 h-3.5" />
              )}
            </motion.button>
          </div>
        </div>

        {/* Bottom hint */}
        <div
          className="px-4 pb-2 flex items-center justify-between"
          style={{ borderTop: "1px solid var(--border-subtle)" }}
        >
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-3 h-3" style={{ color: "var(--accent)" }} />
            <span className="text-xs" style={{ color: "var(--text-muted)" }}>
              Nexus AI · Powered by GPT-4o
            </span>
          </div>
          <span className="text-xs" style={{ color: "var(--text-muted)" }}>
            {input.length > 0 && `${input.length} chars`}
            {input.length === 0 && "⏎ to send · ⇧⏎ new line"}
          </span>
        </div>
      </motion.div>
    </div>
  );
}
