"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Plus, Trash2, MessageSquare, ChevronRight, Sun, Moon,
  Sparkles, Settings, Search, X,
} from "lucide-react";
import type { Chat } from "@/hooks/useChat";

interface SidebarProps {
  chats: Chat[];
  activeChatId: string | null;
  theme: "dark" | "light";
  onSelectChat: (id: string) => void;
  onNewChat: () => void;
  onDeleteChat: (id: string) => void;
  onToggleTheme: () => void;
  onClearAll: () => void;
  isOpen?: boolean;
  onClose?: () => void;
}

export default function Sidebar({
  chats, activeChatId, theme, onSelectChat, onNewChat,
  onDeleteChat, onToggleTheme, onClearAll, isOpen = true, onClose,
}: SidebarProps) {
  const [search, setSearch] = useState("");
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  const filtered = chats.filter((c) =>
    c.title.toLowerCase().includes(search.toLowerCase())
  );

  const grouped = {
    today: filtered.filter((c) => {
      const d = new Date(c.updatedAt);
      const now = new Date();
      return d.toDateString() === now.toDateString();
    }),
    yesterday: filtered.filter((c) => {
      const d = new Date(c.updatedAt);
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      return d.toDateString() === yesterday.toDateString();
    }),
    older: filtered.filter((c) => {
      const d = new Date(c.updatedAt);
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      yesterday.setHours(0, 0, 0, 0);
      return d < yesterday;
    }),
  };

  return (
    <motion.aside
      initial={false}
      animate={{ x: isOpen ? 0 : "-100%" }}
      transition={{ type: "spring", damping: 28, stiffness: 260 }}
      className="h-full flex flex-col relative z-20"
      style={{
        background: "var(--sidebar-bg)",
        backdropFilter: "blur(40px) saturate(180%)",
        borderRight: "1px solid var(--border-subtle)",
        width: "260px",
        minWidth: "260px",
      }}
    >
      {/* Logo */}
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div
            className="w-8 h-8 rounded-xl flex items-center justify-center animate-pulse-glow"
            style={{ background: "linear-gradient(135deg, #5a6ef8, #3d4eec)" }}
          >
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <div>
            <h1 className="text-sm font-bold leading-none" style={{ fontFamily: "var(--font-display)", color: "var(--text-primary)" }}>
              Nexus AI
            </h1>
            <p className="text-xs mt-0.5" style={{ color: "var(--text-muted)" }}>Premium Intelligence</p>
          </div>
        </div>
        {onClose && (
          <button onClick={onClose} className="w-7 h-7 rounded-lg flex items-center justify-center lg:hidden" style={{ color: "var(--text-muted)" }}>
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* New Chat */}
      <div className="px-3 pb-3">
        <motion.button
          onClick={onNewChat}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.97 }}
          className="w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all duration-200"
          style={{
            background: "linear-gradient(135deg, #5a6ef8, #3d4eec)",
            color: "#fff",
            boxShadow: "0 4px 16px rgba(90,110,248,0.3)",
          }}
        >
          <Plus className="w-4 h-4" />
          New Chat
        </motion.button>
      </div>

      {/* Search */}
      <div className="px-3 pb-3">
        <div
          className="flex items-center gap-2 px-3 py-2 rounded-xl"
          style={{ background: "var(--border-subtle)", border: "1px solid var(--border-subtle)" }}
        >
          <Search className="w-3.5 h-3.5 flex-shrink-0" style={{ color: "var(--text-muted)" }} />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search chats…"
            className="flex-1 bg-transparent text-xs focus:outline-none"
            style={{ color: "var(--text-primary)" }}
          />
        </div>
      </div>

      {/* Chat List */}
      <div className="flex-1 overflow-y-auto px-2 space-y-1 pb-4">
        {chats.length === 0 && (
          <div className="text-center py-8 px-4">
            <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-20" style={{ color: "var(--text-muted)" }} />
            <p className="text-xs" style={{ color: "var(--text-muted)" }}>No conversations yet</p>
            <p className="text-xs mt-1" style={{ color: "var(--text-muted)", opacity: 0.6 }}>Start a new chat above</p>
          </div>
        )}

        {Object.entries(grouped).map(([group, items]) =>
          items.length === 0 ? null : (
            <div key={group}>
              <p
                className="text-xs font-semibold uppercase tracking-wider px-2 py-1.5 mb-1"
                style={{ color: "var(--text-muted)", fontSize: "10px", letterSpacing: "0.08em" }}
              >
                {group === "today" ? "Today" : group === "yesterday" ? "Yesterday" : "Older"}
              </p>
              <AnimatePresence>
                {items.map((chat) => (
                  <motion.div
                    key={chat.id}
                    layout
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    onHoverStart={() => setHoveredId(chat.id)}
                    onHoverEnd={() => setHoveredId(null)}
                    className="relative mb-0.5"
                  >
                    <button
                      onClick={() => { onSelectChat(chat.id); onClose?.(); }}
                      className="w-full text-left flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition-all duration-150 group"
                      style={{
                        background: activeChatId === chat.id
                          ? "var(--accent-glow)"
                          : hoveredId === chat.id ? "var(--border-subtle)" : "transparent",
                        border: activeChatId === chat.id ? "1px solid var(--accent-glow)" : "1px solid transparent",
                      }}
                    >
                      <MessageSquare
                        className="w-3.5 h-3.5 flex-shrink-0"
                        style={{ color: activeChatId === chat.id ? "var(--accent)" : "var(--text-muted)" }}
                      />
                      <span
                        className="flex-1 truncate text-xs font-medium"
                        style={{ color: activeChatId === chat.id ? "var(--accent)" : "var(--text-secondary)" }}
                      >
                        {chat.title}
                      </span>

                      {/* Delete button */}
                      <AnimatePresence>
                        {(hoveredId === chat.id || activeChatId === chat.id) && (
                          <motion.button
                            initial={{ opacity: 0, scale: 0.8 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.8 }}
                            onClick={(e) => { e.stopPropagation(); onDeleteChat(chat.id); }}
                            className="w-5 h-5 flex-shrink-0 rounded-md flex items-center justify-center hover:bg-red-500/10 hover:text-red-400 transition-colors"
                            style={{ color: "var(--text-muted)" }}
                          >
                            <Trash2 className="w-3 h-3" />
                          </motion.button>
                        )}
                      </AnimatePresence>
                    </button>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )
        )}
      </div>

      {/* Bottom Actions */}
      <div className="p-3 border-t space-y-1" style={{ borderColor: "var(--border-subtle)" }}>
        <button
          onClick={onToggleTheme}
          className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-medium transition-all duration-150 hover:scale-[1.02]"
          style={{ color: "var(--text-secondary)", background: "var(--border-subtle)" }}
        >
          {theme === "dark" ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
          {theme === "dark" ? "Light Mode" : "Dark Mode"}
        </button>

        {chats.length > 0 && (
          <button
            onClick={onClearAll}
            className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-medium transition-all duration-150 hover:bg-red-500/10 hover:text-red-400"
            style={{ color: "var(--text-muted)" }}
          >
            <Trash2 className="w-3.5 h-3.5" />
            Clear All Chats
          </button>
        )}
      </div>
    </motion.aside>
  );
}
