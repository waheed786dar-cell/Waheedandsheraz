'use client'

import { motion } from 'framer-motion'
import { Menu, Sun, Moon, Sparkles, MoreHorizontal } from 'lucide-react'
import { useTheme } from './ThemeProvider'
import { Conversation } from '@/hooks/useChat'

interface HeaderProps {
  activeConversation: Conversation | null
  onMenuToggle: () => void
  onNewChat: () => void
}

export default function Header({ activeConversation, onMenuToggle, onNewChat }: HeaderProps) {
  const { theme, toggleTheme } = useTheme()

  return (
    <header
      className="flex items-center justify-between px-4 py-3 shrink-0 safe-top"
      style={{
        background: 'var(--glass)',
        backdropFilter: 'blur(20px)',
        borderBottom: '1px solid var(--border)',
        boxShadow: 'var(--shadow-sm)',
      }}
    >
      {/* Left: hamburger (mobile) */}
      <div className="flex items-center gap-2">
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={onMenuToggle}
          className="md:hidden p-2 rounded-xl transition-all"
          style={{ color: 'var(--text-secondary)' }}
          aria-label="Open sidebar"
        >
          <Menu size={20} />
        </motion.button>

        {/* Desktop logo (only shown when no title) */}
        <div className="hidden md:flex items-center gap-2.5">
          <div
            className="w-7 h-7 rounded-lg flex items-center justify-center"
            style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' }}
          >
            <Sparkles size={13} className="text-white" />
          </div>
        </div>
      </div>

      {/* Center: title */}
      <div className="flex-1 text-center md:text-left md:ml-2">
        <h1
          className="text-sm font-semibold truncate max-w-[200px] md:max-w-xs mx-auto md:mx-0"
          style={{ color: 'var(--text-primary)' }}
        >
          {activeConversation?.title || 'Nexus AI'}
        </h1>
        {activeConversation && (
          <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
            {activeConversation.messages.length} messages
          </p>
        )}
      </div>

      {/* Right: actions */}
      <div className="flex items-center gap-1">
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={toggleTheme}
          className="p-2 rounded-xl transition-all"
          style={{ color: 'var(--text-secondary)' }}
          aria-label="Toggle theme"
        >
          {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
        </motion.button>

        <motion.button
          whileTap={{ scale: 0.9 }}
          className="p-2 rounded-xl transition-all md:hidden"
          style={{ color: 'var(--text-secondary)' }}
          aria-label="More options"
        >
          <MoreHorizontal size={18} />
        </motion.button>
      </div>
    </header>
  )
}
