# 🚀 Nexus AI — Premium AI Chatbot

A stunning, full-featured AI chatbot built with Next.js 14, Tailwind CSS, and Framer Motion.

## ✨ Features

- **Real-time streaming** responses via Edge Runtime
- **Chat History** with LocalStorage persistence (sidebar + mobile drawer)
- **Dark/Light mode** with system preference detection
- **Markdown rendering** with syntax-highlighted code blocks + copy buttons
- **Auto-scroll** to latest messages
- **Voice-to-text** via Web Speech API
- **Image upload** UI with drag & drop
- **Glassmorphism** design with smooth animations
- **PWA ready** (manifest.json + service worker)
- **Mobile-first** responsive design

## 📁 Folder Structure

```
nexus-ai/
├── app/
│   ├── layout.tsx          # Root layout (fonts, metadata, PWA)
│   ├── page.tsx            # Main chat page
│   ├── globals.css         # CSS variables, glass, animations
│   └── api/
│       └── chat/
│           └── route.ts    # Edge streaming API (OpenAI + Anthropic)
├── components/
│   ├── ChatInput.tsx       # Input bar (voice, image, send)
│   ├── MessageBubble.tsx   # Message renderer (markdown, code)
│   └── Sidebar.tsx         # Chat history sidebar/drawer
├── hooks/
│   └── useChat.ts          # State management + localStorage
├── public/
│   ├── manifest.json       # PWA manifest
│   └── sw.js               # Service Worker
├── tailwind.config.ts
├── next.config.mjs
└── .env.local.example      # API key template
```

## 🚀 Quick Start

```bash
npm install
cp .env.local.example .env.local
# Add your OPENAI_API_KEY or ANTHROPIC_API_KEY
npm run dev
```

## 🔑 API Keys

Add ONE key to `.env.local`:
```
OPENAI_API_KEY=sk-...       # Uses GPT-4o
ANTHROPIC_API_KEY=sk-ant-... # Uses Claude 3.5 Sonnet
```

Without a key, a demo response is streamed so you can test the full UI.

## 📱 PWA / APK

The app is PWA-ready. To create an APK:
1. Deploy to Vercel/Netlify
2. Use [PWABuilder](https://pwabuilder.com) or Bubblewrap CLI
3. Or wrap with Capacitor: `npx cap init && npx cap add android`
