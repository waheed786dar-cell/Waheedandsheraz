"use client";

import { useState, useCallback, useRef } from "react";
import { v4 as uuidv4 } from "uuid";

export type MessageRole = "user" | "assistant";

export interface Message {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: Date;
  imageUrl?: string;
}

export interface Chat {
  id: string;
  title: string;
  messages: Message[];
  createdAt: Date;
  updatedAt: Date;
}

const STORAGE_KEY = "nexus-chats";
const THEME_KEY = "nexus-theme";

function loadChats(): Chat[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Chat[];
    return parsed.map((c) => ({
      ...c,
      createdAt: new Date(c.createdAt),
      updatedAt: new Date(c.updatedAt),
      messages: c.messages.map((m) => ({ ...m, timestamp: new Date(m.timestamp) })),
    }));
  } catch {
    return [];
  }
}

function saveChats(chats: Chat[]) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(chats));
  } catch {}
}

function generateTitle(firstMessage: string): string {
  const words = firstMessage.trim().split(/\s+/).slice(0, 6).join(" ");
  return words.length < firstMessage.length ? `${words}…` : words;
}

export function useChat() {
  const [chats, setChats] = useState<Chat[]>(() => loadChats());
  const [activeChatId, setActiveChatId] = useState<string | null>(() => {
    const saved = loadChats();
    return saved.length > 0 ? saved[0].id : null;
  });
  const [isStreaming, setIsStreaming] = useState(false);
  const [theme, setTheme] = useState<"dark" | "light">(() => {
    if (typeof window === "undefined") return "dark";
    const saved = localStorage.getItem(THEME_KEY);
    if (saved === "dark" || saved === "light") return saved;
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  });
  const abortRef = useRef<AbortController | null>(null);

  const activeChat = chats.find((c) => c.id === activeChatId) ?? null;

  const persistChats = useCallback((updated: Chat[]) => {
    setChats(updated);
    saveChats(updated);
  }, []);

  const createNewChat = useCallback((): string => {
    const id = uuidv4();
    const newChat: Chat = {
      id,
      title: "New Chat",
      messages: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    const updated = [newChat, ...chats];
    persistChats(updated);
    setActiveChatId(id);
    return id;
  }, [chats, persistChats]);

  const deleteChat = useCallback(
    (chatId: string) => {
      const updated = chats.filter((c) => c.id !== chatId);
      persistChats(updated);
      if (activeChatId === chatId) {
        setActiveChatId(updated.length > 0 ? updated[0].id : null);
      }
    },
    [chats, persistChats, activeChatId]
  );

  const sendMessage = useCallback(
    async (content: string, imageUrl?: string) => {
      if (!content.trim() && !imageUrl) return;
      if (isStreaming) return;

      let chatId = activeChatId;
      let currentChats = chats;

      // Create a new chat if none active
      if (!chatId) {
        const id = uuidv4();
        const newChat: Chat = {
          id,
          title: generateTitle(content),
          messages: [],
          createdAt: new Date(),
          updatedAt: new Date(),
        };
        currentChats = [newChat, ...chats];
        persistChats(currentChats);
        setActiveChatId(id);
        chatId = id;
      }

      const userMsg: Message = {
        id: uuidv4(),
        role: "user",
        content,
        timestamp: new Date(),
        imageUrl,
      };

      const assistantMsg: Message = {
        id: uuidv4(),
        role: "assistant",
        content: "",
        timestamp: new Date(),
      };

      // Add user message and placeholder
      const withUser = currentChats.map((c) =>
        c.id === chatId
          ? {
              ...c,
              messages: [...c.messages, userMsg, assistantMsg],
              title: c.messages.length === 0 ? generateTitle(content) : c.title,
              updatedAt: new Date(),
            }
          : c
      );
      persistChats(withUser);
      setIsStreaming(true);

      // Build message history for API
      const chatHistory = currentChats.find((c) => c.id === chatId)?.messages ?? [];
      const apiMessages = chatHistory.map((m) => ({ role: m.role, content: m.content }));
      apiMessages.push({ role: "user", content });

      abortRef.current = new AbortController();

      try {
        const res = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ messages: apiMessages }),
          signal: abortRef.current.signal,
        });

        if (!res.ok || !res.body) throw new Error("Stream failed");

        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let accumulated = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value, { stream: true });
          const lines = chunk.split("\n");

          for (const line of lines) {
            if (line.startsWith("data: ")) {
              const data = line.slice(6).trim();
              if (data === "[DONE]") break;
              try {
                const parsed = JSON.parse(data);
                const delta = parsed.choices?.[0]?.delta?.content ?? "";
                if (delta) {
                  accumulated += delta;
                  setChats((prev) => {
                    const updated = prev.map((c) =>
                      c.id === chatId
                        ? {
                            ...c,
                            messages: c.messages.map((m) =>
                              m.id === assistantMsg.id ? { ...m, content: accumulated } : m
                            ),
                          }
                        : c
                    );
                    saveChats(updated);
                    return updated;
                  });
                }
              } catch {}
            }
          }
        }
      } catch (err: unknown) {
        if (err instanceof Error && err.name !== "AbortError") {
          setChats((prev) => {
            const updated = prev.map((c) =>
              c.id === chatId
                ? {
                    ...c,
                    messages: c.messages.map((m) =>
                      m.id === assistantMsg.id
                        ? { ...m, content: "⚠️ Something went wrong. Please check your API route and try again." }
                        : m
                    ),
                  }
                : c
            );
            saveChats(updated);
            return updated;
          });
        }
      } finally {
        setIsStreaming(false);
      }
    },
    [activeChatId, chats, isStreaming, persistChats]
  );

  const stopStreaming = useCallback(() => {
    abortRef.current?.abort();
    setIsStreaming(false);
  }, []);

  const toggleTheme = useCallback(() => {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    document.documentElement.classList.toggle("dark", next === "dark");
    localStorage.setItem(THEME_KEY, next);
  }, [theme]);

  const clearAllChats = useCallback(() => {
    persistChats([]);
    setActiveChatId(null);
  }, [persistChats]);

  return {
    chats,
    activeChat,
    activeChatId,
    isStreaming,
    theme,
    setActiveChatId,
    createNewChat,
    deleteChat,
    sendMessage,
    stopStreaming,
    toggleTheme,
    clearAllChats,
  };
}
