"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, Sparkles, ChevronDown, Zap } from "lucide-react";
import { useChat } from "@/hooks/useChat";
import ChatInput from "@/components/ChatInput";
import MessageBubble from "@/components/MessageBubble";
import Sidebar from "@/components/Sidebar";

const WELCOME_PROMPTS = [
  { icon: "🚀", label: "Explain quantum computing", color: "#5a6ef8" },
  { icon: "💻", label: "Write a React component", color: "#06b6d4" },
  { icon: "✍️", label: "Help me write an email", color: "#8b5cf6" },
  { icon: "🧠", label: "Solve a logic puzzle", color: "#f59e0b" },
];

export default function Home() {
  const {
    chats, activeChat, activeChatId, isStreaming, theme,
    setActiveChatId, createNewChat, deleteChat, sendMessage,
    stopStreaming, toggleTheme, clearAllChats,
  } = useChat();

  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showScrollBtn, setShowScrollBtn] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const lastMessageCount = useRef(0);

  // Auto-scroll
  const scrollToBottom = useCallback((smooth = true) => {
    messagesEndRef.current?.scrollIntoView({ behavior: smooth ? "smooth" : "auto" });
  }, []);

  useEffect(() => {
    const msgs = activeChat?.messages ?? [];
    if (msgs.length !== lastMessageCount.current) {
      lastMessageCount.current = msgs.length;
      scrollToBottom();
    } else if (isStreaming) {
      scrollToBottom(false);
    }
  }, [activeChat?.messages, isStreaming, scrollToBottom]);

  // Scroll button visibility
  useEffect(() => {
    const container = messagesContainerRef.current;
    if (!container) return;
    const handler = () => {
      const fromBottom = container.scrollHeight - container.scrollTop - container.clientHeight;
      setShowScrollBtn(fromBottom > 200);
    };
    container.addEventListener("scroll", handler, { passive: true });
    return () => container.removeEventListener("scroll", handler);
  }, []);

  const messages = activeChat?.messages ?? [];
  const hasMessages = messages.length > 0;

  return (
    <div className="h-screen flex overflow-hidden relative" style={{ background: "var(--bg-primary)" }}>
      {/* Background glow orbs */}
      <div
        className="glow-orb"
        style={{
          width: "600px", height: "600px",
          top: "-200px", left: "-100px",
          background: "radial-gradient(circle, rgba(90,110,248,0.08) 0%, transparent 70%)",
        }}
      />
      <div
        className="glow-orb"
        style={{
          width: "400px", height: "400px",
          bottom: "-100px", right: "100px",
          background: "radial-gradient(circle, rgba(167,139,250,0.06) 0%, transparent 70%)",
        }}
      />

      {/* Desktop Sidebar */}
      <div className="hidden lg:flex h-full">
        <Sidebar
          chats={chats}
          activeChatId={activeChatId}
          theme={theme}
          onSelectChat={setActiveChatId}
          onNewChat={createNewChat}
          onDeleteChat={deleteChat}
          onToggleTheme={toggleTheme}
          onClearAll={clearAllChats}
          isOpen={true}
        />
      </div>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSidebarOpen(false)}
              className="fixed inset-0 z-30 lg:hidden"
              style={{ background: "rgba(0,0,0,0.5)", backdropFilter: "blur(4px)" }}
            />
            <motion.div
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", damping: 28, stiffness: 260 }}
              className="fixed left-0 top-0 h-full z-40 lg:hidden"
            >
              <Sidebar
                chats={chats}
                activeChatId={activeChatId}
                theme={theme}
                onSelectChat={setActiveChatId}
                onNewChat={createNewChat}
                onDeleteChat={deleteChat}
                onToggleTheme={toggleTheme}
                onClearAll={clearAllChats}
                isOpen={true}
                onClose={() => setSidebarOpen(false)}
              />
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {/* Header */}
        <header
          className="flex items-center justify-between px-4 py-3 safe-top glass-heavy"
          style={{
            borderBottom: "1px solid var(--border-subtle)",
            background: "var(--bg-glass)",
            backdropFilter: "blur(20px)",
          }}
        >
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden w-9 h-9 rounded-xl flex items-center justify-center transition-all hover:scale-105 active:scale-95"
              style={{ color: "var(--text-secondary)", background: "var(--border-subtle)" }}
            >
              <Menu className="w-4 h-4" />
            </button>
            <div>
              <h2
                className="text-sm font-bold leading-none truncate max-w-[200px]"
                style={{ fontFamily: "var(--font-display)", color: "var(--text-primary)" }}
              >
                {activeChat?.title || "Nexus AI"}
              </h2>
              <div className="flex items-center gap-1.5 mt-0.5">
                <div
                  className="w-1.5 h-1.5 rounded-full"
                  style={{ background: isStreaming ? "#f59e0b" : "#22c55e",
                    boxShadow: `0 0 6px ${isStreaming ? "#f59e0b" : "#22c55e"}` }}
                />
                <span className="text-xs" style={{ color: "var(--text-muted)" }}>
                  {isStreaming ? "Generating…" : "Ready"}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium"
              style={{ background: "var(--border-subtle)", color: "var(--text-muted)" }}
            >
              <Zap className="w-3 h-3" style={{ color: "var(--accent)" }} />
              GPT-4o
            </div>
          </div>
        </header>

        {/* Messages Area */}
        <div
          ref={messagesContainerRef}
          className="flex-1 overflow-y-auto"
          style={{ overscrollBehavior: "contain" }}
        >
          <div className="max-w-3xl mx-auto px-4 py-6">
            {!hasMessages ? (
              /* Welcome Screen */
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, ease: "easeOut" }}
                className="flex flex-col items-center justify-center min-h-[60vh] text-center"
              >
                <motion.div
                  animate={{ rotate: [0, 5, -5, 0], scale: [1, 1.05, 1] }}
                  transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
                  className="w-20 h-20 rounded-2xl flex items-center justify-center mb-6"
                  style={{
                    background: "linear-gradient(135deg, #5a6ef8 0%, #3d4eec 50%, #8b5cf6 100%)",
                    boxShadow: "0 20px 60px rgba(90,110,248,0.3), 0 8px 24px rgba(90,110,248,0.2)",
                  }}
                >
                  <Sparkles className="w-9 h-9 text-white" />
                </motion.div>

                <h1
                  className="text-3xl font-extrabold mb-3"
                  style={{ fontFamily: "var(--font-display)", color: "var(--text-primary)" }}
                >
                  Good{" "}
                  {new Date().getHours() < 12 ? "morning" : new Date().getHours() < 18 ? "afternoon" : "evening"}
                  <span className="gradient-text"> ✦</span>
                </h1>
                <p className="text-base mb-10 max-w-md leading-relaxed" style={{ color: "var(--text-secondary)" }}>
                  I'm Nexus, your premium AI assistant. Ask me anything — from complex code to creative writing.
                </p>

                <div className="grid grid-cols-2 gap-3 w-full max-w-sm">
                  {WELCOME_PROMPTS.map((p, i) => (
                    <motion.button
                      key={i}
                      initial={{ opacity: 0, y: 16 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.1 + i * 0.08 }}
                      whileHover={{ scale: 1.03, y: -2 }}
                      whileTap={{ scale: 0.97 }}
                      onClick={() => sendMessage(p.label)}
                      className="glass-heavy text-left p-4 rounded-2xl flex items-start gap-3 group transition-all duration-200"
                      style={{ border: "1px solid var(--border-subtle)" }}
                    >
                      <span className="text-2xl">{p.icon}</span>
                      <span
                        className="text-xs font-medium leading-snug"
                        style={{ color: "var(--text-secondary)" }}
                      >
                        {p.label}
                      </span>
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            ) : (
              /* Messages */
              <div className="space-y-6">
                <AnimatePresence initial={false}>
                  {messages.map((msg, i) => (
                    <MessageBubble
                      key={msg.id}
                      message={msg}
                      isStreaming={isStreaming && i === messages.length - 1 && msg.role === "assistant"}
                      theme={theme}
                      index={i}
                    />
                  ))}
                </AnimatePresence>
                <div ref={messagesEndRef} className="h-4" />
              </div>
            )}
          </div>
        </div>

        {/* Scroll to bottom button */}
        <AnimatePresence>
          {showScrollBtn && hasMessages && (
            <motion.button
              initial={{ opacity: 0, scale: 0.8, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 10 }}
              onClick={() => scrollToBottom()}
              className="absolute right-6 bottom-32 w-9 h-9 rounded-full flex items-center justify-center glass-heavy shadow-lg"
              style={{
                border: "1px solid var(--border-medium)",
                color: "var(--text-secondary)",
                zIndex: 10,
              }}
            >
              <ChevronDown className="w-4 h-4" />
            </motion.button>
          )}
        </AnimatePresence>

        {/* Input Area */}
        <div
          className="px-4 pt-3 pb-4 safe-bottom"
          style={{
            background: "var(--bg-glass)",
            backdropFilter: "blur(20px)",
            borderTop: "1px solid var(--border-subtle)",
          }}
        >
          <div className="max-w-3xl mx-auto">
            <ChatInput
              onSend={sendMessage}
              onStop={stopStreaming}
              isStreaming={isStreaming}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
