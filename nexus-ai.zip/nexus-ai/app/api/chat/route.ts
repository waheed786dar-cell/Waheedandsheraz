import { NextRequest } from "next/server";

export const runtime = "edge";

const SYSTEM_PROMPT = `You are Nexus, a premium AI assistant. You are helpful, articulate, and thoughtful. 
You format responses beautifully using markdown: use headers, bullet points, code blocks, and tables where appropriate.
For code, always specify the language for syntax highlighting.
Keep responses clear, concise, and genuinely helpful. 
If you don't know something, say so honestly.`;

export async function POST(req: NextRequest) {
  try {
    const { messages } = await req.json();

    const apiKey = process.env.OPENAI_API_KEY || process.env.ANTHROPIC_API_KEY;

    if (!apiKey) {
      // Return a demo stream response when no API key is configured
      const demoResponse = `# Welcome to Nexus AI! 🚀

I'm your premium AI assistant. To get started with **real AI responses**, you'll need to:

1. Add your API key to \`.env.local\`:
\`\`\`bash
OPENAI_API_KEY=sk-your-key-here
# or
ANTHROPIC_API_KEY=sk-ant-your-key-here
\`\`\`

2. Restart the development server

## What I can do for you:
- 💬 **Natural conversation** — Ask me anything
- 💻 **Code assistance** — Write, debug, explain code
- 📝 **Writing help** — Drafts, edits, summaries
- 🧠 **Analysis** — Complex reasoning and research

> This is a **demo response** since no API key is configured. The UI is fully functional with streaming, chat history, dark/light mode, and all features ready!

You sent: *"${messages[messages.length - 1]?.content}"*`;

      const encoder = new TextEncoder();
      const stream = new ReadableStream({
        async start(controller) {
          const words = demoResponse.split("");
          for (let i = 0; i < words.length; i += 3) {
            const chunk = words.slice(i, i + 3).join("");
            const data = JSON.stringify({
              choices: [{ delta: { content: chunk } }],
            });
            controller.enqueue(encoder.encode(`data: ${data}\n\n`));
            await new Promise((r) => setTimeout(r, 8));
          }
          controller.enqueue(encoder.encode("data: [DONE]\n\n"));
          controller.close();
        },
      });

      return new Response(stream, {
        headers: {
          "Content-Type": "text/event-stream",
          "Cache-Control": "no-cache",
          Connection: "keep-alive",
        },
      });
    }

    // Use Anthropic API if key starts with sk-ant
    if (apiKey.startsWith("sk-ant")) {
      const anthropicRes = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": apiKey,
          "anthropic-version": "2023-06-01",
          "anthropic-beta": "messages-2023-12-15",
        },
        body: JSON.stringify({
          model: "claude-3-5-sonnet-20241022",
          max_tokens: 4096,
          system: SYSTEM_PROMPT,
          messages: messages.slice(-20),
          stream: true,
        }),
      });

      // Convert Anthropic SSE to OpenAI-compatible SSE
      const encoder = new TextEncoder();
      const reader = anthropicRes.body!.getReader();
      const decoder = new TextDecoder();

      const stream = new ReadableStream({
        async start(controller) {
          try {
            while (true) {
              const { done, value } = await reader.read();
              if (done) break;
              const text = decoder.decode(value, { stream: true });
              const lines = text.split("\n");
              for (const line of lines) {
                if (line.startsWith("data: ")) {
                  const data = line.slice(6);
                  try {
                    const parsed = JSON.parse(data);
                    if (parsed.type === "content_block_delta" && parsed.delta?.text) {
                      const compatible = JSON.stringify({
                        choices: [{ delta: { content: parsed.delta.text } }],
                      });
                      controller.enqueue(encoder.encode(`data: ${compatible}\n\n`));
                    } else if (parsed.type === "message_stop") {
                      controller.enqueue(encoder.encode("data: [DONE]\n\n"));
                    }
                  } catch {}
                }
              }
            }
          } finally {
            controller.close();
          }
        },
      });

      return new Response(stream, {
        headers: {
          "Content-Type": "text/event-stream",
          "Cache-Control": "no-cache",
        },
      });
    }

    // OpenAI
    const openaiRes = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o",
        messages: [{ role: "system", content: SYSTEM_PROMPT }, ...messages.slice(-20)],
        stream: true,
        max_tokens: 4096,
      }),
    });

    return new Response(openaiRes.body, {
      headers: {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
      },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: "Internal error" }), { status: 500 });
  }
}
